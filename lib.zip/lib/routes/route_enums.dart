




enum AppRoute{
  home,
  detail
}