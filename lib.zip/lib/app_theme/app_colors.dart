
import 'package:flutter/material.dart';

class AppColors {
  static Color backGroundColor = Color(0xFFF1F5F9);

}